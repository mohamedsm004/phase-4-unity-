using System;
using System.Collections.Generic;

[Serializable]
public class Node
{
    public string node_id;
    public int cluster_label;
    public float cluster_prob;     // Changé en float (était 1.0)
    public float anomaly_score;    // Changé en float (était 0.9639...)
    public int anomaly_label;
    public string risk_level;
    public string display_color;
    public float display_size;     // Changé en float (était 1.2079...)
    public string display_shape;
    public string account_type;
    public int is_fraud_node;
    public float total_tx_count;   // Corrigé l'orthographe 'total' et mis en float (1.0)
    public float total_amount;     // Corrigé l'orthographe 'total' et mis en float (10000000.0)

    // Vos coordonnées sont parfaites
    public float x;
    public float y;
    public float z;
}

[Serializable]
public class NodeContainer
{
    public int total;
    public int limit;
    public int offset;
    public List<Node> items;
}