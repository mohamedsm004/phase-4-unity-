using UnityEngine;

public class CameraOrbit : MonoBehaviour
{
    public float speed = 20f;
    public float sensitivity = 2f;

    void Update()
    {
        // Déplacement de la caméra avec les touches Z, Q, S, D (ou les flèches)
        float moveForward = Input.GetAxis("Vertical") * speed * Time.deltaTime;
        float moveSide = Input.GetAxis("Horizontal") * speed * Time.deltaTime;
        transform.Translate(new Vector3(moveSide, 0, moveForward));

        // Rotation de la caméra en maintenant le clic droit de la souris enfoncé
        if (Input.GetMouseButton(1))
        {
            float rotateX = Input.GetAxis("Mouse X") * sensitivity;
            float rotateY = -Input.GetAxis("Mouse Y") * sensitivity;
            transform.Rotate(Vector3.up, rotateX, Space.World);
            transform.Rotate(Vector3.right, rotateY, Space.Self);
        }
    }
}