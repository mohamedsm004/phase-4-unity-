using System;
using System.Collections.Generic;

[Serializable]
public class Edge
{
    public string source; // L'ID du nœud de départ (ex: "C1351320610")
    public string target; // L'ID du nœud d'arrivée
    // Ajoutez d'autres champs si votre JSON en contient (ex: weight, amount...)
    public int step;
    public string type;
    public float amount;
    public float log_amount;
    public int is_fraud;
    public float balance_diff_orig;
    public float balance_diff_dest;
    public int orig_account_emptied;
    public int edge_id;

}

[Serializable]
public class EdgeContainer
{
    public List<Edge> items;
}