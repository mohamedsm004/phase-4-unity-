using UnityEngine;
using UnityEngine.Networking;
using System.Collections;
using System.Collections.Generic;

public class GraphClient : MonoBehaviour
{
    // On charge le paquet d'edges de départ
    private string edgesUrl = "http://127.0.0.1:8010/api/edges?limit=50";

    // URL de base pour les nœuds (on va gérer le parcours total dynamiquement par paquets)
    private string baseNodesUrl = "http://127.0.0.1:8010/api/nodes";

    public float graphScale = 2700f;
    public float spreadAmount = 500f;

    private GameObject nodePrefab;
    private Dictionary<string, GameObject> instantiatedNodes = new Dictionary<string, GameObject>();

    void Start()
    {
        nodePrefab = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        nodePrefab.transform.localScale = new Vector3(7f, 7f, 7f);
        nodePrefab.SetActive(false);

        StartCoroutine(LoadFullInducedSubgraph());
    }

    IEnumerator LoadFullInducedSubgraph()
    {
        // ==================================================================
        // ÉTAPE 1 : Charger l'ensemble de vos Edges & collecter les extrémités
        // ==================================================================
        EdgeContainer edgeData = null;
        HashSet<string> requiredNodeIDs = new HashSet<string>();

        using (UnityWebRequest edgeRequest = UnityWebRequest.Get(edgesUrl))
        {
            yield return edgeRequest.SendWebRequest();
            if (edgeRequest.result == UnityWebRequest.Result.Success)
            {
                edgeData = JsonUtility.FromJson<EdgeContainer>(edgeRequest.downloadHandler.text);
                foreach (Edge edge in edgeData.items)
                {
                    requiredNodeIDs.Add(edge.source.Trim());
                    requiredNodeIDs.Add(edge.target.Trim());
                }
                Debug.Log($"📊 Étape 1 : {edgeData.items.Count} liens chargés. Recherche de {requiredNodeIDs.Count} nœuds uniques lancée sur TOUTE l'API...");
            }
            else
            {
                Debug.LogError("❌ Erreur au chargement des Edges.");
                yield break;
            }
        }

        // ==================================================================
        // ÉTAPE 2 : Parcours TOTAL et exhaustif de TOUS les nœuds de l'API
        // ==================================================================
        int currentOffset = 0;
        int chunkSize = 10000; // On inspecte les nœuds par paquets massifs de 10 000 pour aller très vite
        bool possessesMoreNodes = true;
        int totalNodesInspected = 0;

        while (possessesMoreNodes)
        {
            string paginatedNodesUrl = $"{baseNodesUrl}?limit={chunkSize}&offset={currentOffset}";

            using (UnityWebRequest nodeRequest = UnityWebRequest.Get(paginatedNodesUrl))
            {
                yield return nodeRequest.SendWebRequest();

                if (nodeRequest.result == UnityWebRequest.Result.Success)
                {
                    NodeContainer nodeData = JsonUtility.FromJson<NodeContainer>(nodeRequest.downloadHandler.text);

                    // Si l'API renvoie une liste vide, c'est qu'on a atteint la fin des 250 000 nœuds
                    if (nodeData == null || nodeData.items == null || nodeData.items.Count == 0)
                    {
                        possessesMoreNodes = false;
                        break;
                    }

                    totalNodesInspected += nodeData.items.Count;

                    // On inspecte chaque nœud du paquet actuel
                    foreach (Node node in nodeData.items)
                    {
                        string cleanNodeId = node.node_id.Trim();

                        // LE FILTRE EXCLUSIF : Si ce nœud de l'API est une de nos extrémités, on le crée !
                        if (requiredNodeIDs.Contains(cleanNodeId))
                        {
                            BuildNodeObjectInScene(node);
                        }
                    }

                    // Si le paquet reçu est plus petit que la limite demandée, on est sur la dernière page
                    if (nodeData.items.Count < chunkSize)
                    {
                        possessesMoreNodes = false;
                    }
                    else
                    {
                        currentOffset += chunkSize; // On passe à la page suivante
                    }
                }
                else
                {
                    Debug.LogError($"❌ Erreur de lecture au nœud numéro {currentOffset}. Fin du parcours forcé.");
                    possessesMoreNodes = false;
                }
            }

            // Permet d'éviter de figer l'écran de Unity pendant la boucle de lecture intensive
            yield return null;
        }

        Debug.Log($"✅ Étape 2 terminée : {totalNodesInspected} nœuds ont été scannés sans exception. {instantiatedNodes.Count} extrémités réelles ont été trouvées et créées.");

        // ==================================================================
        // ÉTAPE 3 : Dessiner les lignes physiques entre les correspondances
        // ==================================================================
        int finalEdgesDrawn = 0;

        foreach (Edge edge in edgeData.items)
        {
            string cleanSource = edge.source.Trim();
            string cleanTarget = edge.target.Trim();

            // On ne trace que si la source ET la cible ont été découvertes lors du grand parcours
            if (instantiatedNodes.ContainsKey(cleanSource) && instantiatedNodes.ContainsKey(cleanTarget))
            {
                finalEdgesDrawn++;
                Vector3 posSource = instantiatedNodes[cleanSource].transform.position;
                Vector3 posTarget = instantiatedNodes[cleanTarget].transform.position;

                GameObject lineObj = new GameObject("Edge_" + cleanSource + "_" + cleanTarget);
                LineRenderer lr = lineObj.AddComponent<LineRenderer>();
                lr.material = new Material(Shader.Find("Sprites/Default"));

                if (edge.is_fraud == 1)
                {
                    lr.startColor = Color.red; lr.endColor = Color.red;
                    lr.startWidth = 6f; lr.endWidth = 6f;
                }
                else
                {
                    lr.startColor = Color.white; lr.endColor = Color.yellow;
                    lr.startWidth = 4f; lr.endWidth = 4f;
                }

                lr.useWorldSpace = true;
                lr.positionCount = 2;
                lr.SetPosition(0, posSource);
                lr.SetPosition(1, posTarget);
            }
        }

        Debug.Log($"📊 [VERDICT DU SCAN TOTAL] {instantiatedNodes.Count} Nœuds instanciés | {finalEdgesDrawn} Liens d'origine validés et visibles !");
    }

    // Génère la sphère 3D avec vos paramètres graphiques d'origine
    void BuildNodeObjectInScene(Node node)
    {
        string id = node.node_id.Trim();
        if (instantiatedNodes.ContainsKey(id)) return;

        float baseX = node.x * graphScale;
        float baseY = node.y * graphScale;
        float baseZ = node.z * graphScale;

        float randomX = UnityEngine.Random.Range(-spreadAmount, spreadAmount);
        float randomY = UnityEngine.Random.Range(-spreadAmount, spreadAmount);
        float randomZ = UnityEngine.Random.Range(-spreadAmount, spreadAmount);

        Vector3 position = new Vector3(baseX + randomX, baseY + randomY, baseZ + randomZ);

        GameObject go = Instantiate(nodePrefab, position, Quaternion.identity);
        go.name = id;
        go.SetActive(true);

        Renderer renderer = go.GetComponent<Renderer>();
        if (node.is_fraud_node == 1 || node.risk_level == "critique")
        {
            renderer.material.color = Color.red;
            go.transform.localScale = new Vector3(25f, 25f, 25f);
        }
        else
        {
            go.transform.localScale = new Vector3(8f, 8f, 8f);
            switch (node.cluster_label)
            {
                case 1: renderer.material.color = Color.blue; break;
                case 2: renderer.material.color = Color.green; break;
                case 3: renderer.material.color = Color.cyan; break;
                case 4: renderer.material.color = Color.magenta; break;
                case 5: renderer.material.color = Color.yellow; break;
                default: renderer.material.color = Color.white; break;
            }
        }

        instantiatedNodes.Add(id, go);
    }
}